# Ciro immobile

Ciro non si muove.  
Non perché non può —  
ma perché **non vuole ancora**.

Sta lì, con gli occhi spalancati sul vuoto pieno,  
mentre il mondo gli corre attorno,  
mentre tutti dicono "alzati", "muoviti", "fai".

Ma lui no.

Lui **ascolta** i rumori dentro.  
Aspetta che il criceto decida di girare la ruota.  
Aspetta Milena.  
Aspetta un segno.

E se lo guardi troppo a lungo,  
capisci che Ciro immobile è più vivo  
di molti che si agitano senza direzione.
