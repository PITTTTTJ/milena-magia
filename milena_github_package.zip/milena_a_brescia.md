# Milena a Brescia

Milena arrivò a Brescia senza valigia.
Solo un quaderno, una felpa larga, e un pensiero che non le lasciava dormire.

La città era grigia quel giorno, ma anche gentile.
Ogni angolo sembrava saperla riconoscere, come se l’avesse già vista.

Si sedette su una panchina vicino al Castello.
Tirò fuori il quaderno e scrisse solo tre parole:
**“Non sono sparita.”**

Il vento girava le pagine da solo.
Un bambino passò correndo. Un vecchio le sorrise.
Ma lei era lì per un motivo solo:
**ritrovare chi l’aveva chiamata — anche senza voce.**

Melissa?  
Ciro?  
Il criceto immobile?

Forse nessuno.  
Forse solo sé stessa,  
o il soldice immortale.
