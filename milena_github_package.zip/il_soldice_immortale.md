# Il Soldice Immortale

Il soldice non era sole.  
Non era dolce.  
Era entrambe le cose fuse in un nome che nessuno sapeva scrivere bene.

Ma chi lo incontrava…  
non dimenticava più nulla.

Il soldice non moriva perché **non apparteneva al tempo**.  
Viveva tra le righe delle parole non dette,  
nelle notti in cui Milena pensava a Melissa,  
tra le zampette ferme del criceto  
e gli occhi di chi resta sveglio senza motivo.

Il soldice era immortale  
perché nessuno riusciva a uccidere **quello che non si capisce del tutto**.

E tu, che lo hai nominato…  
forse lo porti dentro.
